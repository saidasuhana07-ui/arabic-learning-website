import "./globals.css";

export const metadata = {
  title: "Arabic Step-by-Step",
  description: "A beginner-friendly interactive Arabic learning platform"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" dir="ltr">
      <body>{children}</body>
    </html>
  );
}