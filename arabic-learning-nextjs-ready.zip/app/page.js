 "use client";

import { useState } from "react";

const lessons = [
  { title: "Arabic Alphabet", icon: "ا", text: "Learn the 28 Arabic letters with simple pronunciation practice." },
  { title: "Greetings", icon: "👋", text: "Practice Marḥaban, Kayfa ḥāluka/ḥāluki, and common replies." },
  { title: "Vowels", icon: "َ", text: "Understand short vowels and long vowels step by step." },
  { title: "Everyday Words", icon: "📚", text: "Build your first practical vocabulary set." }
];

const quiz = [
  { q: "What does مَرْحَبًا (Marḥaban) mean?", options: ["Goodbye", "Hello", "Thank you"], answer: 1 },
  { q: "How do you say “How are you?” to a male?", options: ["Kayfa ḥāluka?", "Min faḍlik", "Shukran"], answer: 0 },
  { q: "What is شُكْرًا (Shukran)?", options: ["Please", "Sorry", "Thank you"], answer: 2 }
];

export default function Home() {
  const [active, setActive] = useState("home");
  const [progress, setProgress] = useState(12);
  const [quizIndex, setQuizIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);

  function speak(text) {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      u.rate = 0.78;
      window.speechSynthesis.speak(u);
    }
  }

  function completeLesson() {
    setProgress(p => Math.min(100, p + 8));
  }

  function answer(i) {
    if (selected !== null) return;
    setSelected(i);
    if (i === quiz[quizIndex].answer) setScore(s => s + 1);
  }

  function nextQuestion() {
    setSelected(null);
    setQuizIndex(i => (i + 1) % quiz.length);
  }

  return (
    <main>
      <header className="topbar">
        <div className="brand"><span className="logo">ع</span><div><strong>Arabic Step-by-Step</strong><small>Learn • Practice • Speak</small></div></div>
        <nav>
          {["home","lessons","quiz","progress"].map(item =>
            <button key={item} className={active===item ? "nav active":"nav"} onClick={()=>setActive(item)}>
              {item[0].toUpperCase()+item.slice(1)}
            </button>
          )}
        </nav>
      </header>

      {active === "home" && <section className="hero">
        <div className="heroText">
          <span className="pill">🌙 Beginner friendly</span>
          <h1>Start Arabic from <span>zero.</span></h1>
          <p>Short lessons, pronunciation practice, exercises and quizzes designed to take you from your first Arabic letter toward real conversation.</p>
          <div className="actions">
            <button className="primary" onClick={()=>setActive("lessons")}>Start learning →</button>
            <button className="secondary" onClick={()=>speak("مَرْحَبًا")}>🔊 Hear Arabic</button>
          </div>
          <div className="stats"><div><b>28</b><span>Letters</span></div><div><b>6</b><span>Levels</span></div><div><b>100+</b><span>Activities</span></div></div>
        </div>
        <div className="arabicCard">
          <div className="moon">☾</div>
          <div className="arabic">مَرْحَبًا</div>
          <div className="trans">Marḥaban</div>
          <div className="meaning">Hello / Welcome</div>
          <button onClick={()=>speak("مَرْحَبًا")} className="sound">🔊 Listen</button>
        </div>
      </section>}

      {active === "lessons" && <section className="content">
        <div className="sectionHead"><div><span className="eyebrow">LEVEL 1</span><h2>Absolute Beginner</h2><p>Build your foundation one small lesson at a time.</p></div><div className="progressBox"><span>Your progress</span><b>{progress}%</b><div className="bar"><i style={{width:`${progress}%`}}/></div></div></div>
        <div className="grid">{lessons.map((l,idx)=><article className="lesson" key={l.title}><div className="lessonIcon">{l.icon}</div><span>Lesson {idx+1}</span><h3>{l.title}</h3><p>{l.text}</p><button onClick={completeLesson}>Complete lesson ✓</button>{l.title==="Greetings" && <button className="listen" onClick={()=>speak("مَرْحَبًا، كَيْفَ حَالُكَ؟")}>🔊 Practice</button>}</article>)}</div>
      </section>}

      {active === "quiz" && <section className="content narrow">
        <span className="eyebrow">QUICK QUIZ</span><h2>Check your Arabic</h2><p className="muted">Question {quizIndex+1} of {quiz.length}</p>
        <div className="quizCard"><h3>{quiz[quizIndex].q}</h3>{quiz[quizIndex].options.map((o,i)=><button key={o} onClick={()=>answer(i)} className={`option ${selected!==null && i===quiz[quizIndex].answer?"correct":""} ${selected===i && i!==quiz[quizIndex].answer?"wrong":""}`}>{o}</button>)}{selected!==null && <div className="quizFoot"><b>{selected===quiz[quizIndex].answer?"Correct! 🎉":"Keep practicing."}</b><span>Score: {score}/{quizIndex+1}</span><button className="primary small" onClick={nextQuestion}>Next →</button></div>}</div>
      </section>}

      {active === "progress" && <section className="content narrow">
        <span className="eyebrow">YOUR JOURNEY</span><h2>Learning progress</h2>
        <div className="bigProgress"><div className="circle">{progress}%</div><div><h3>You're building momentum.</h3><p>Complete lessons and activities to increase your progress.</p><button className="primary" onClick={()=>setActive("lessons")}>Continue learning →</button></div></div>
      </section>}

      <footer><span>Arabic Step-by-Step</span><span>Made for beginners • Keep practicing every day.</span></footer>
    </main>
  );
}