# Arabic Step-by-Step

A beginner-friendly Arabic learning website built with Next.js.

## Run locally

1. Install Node.js 18+.
2. In this folder run:
   npm install
   npm run dev
3. Open http://localhost:3000

## Deploy

Push this repository to GitHub and import it into Netlify or Vercel. The build command is `npm run build` and the publish/deploy is handled by the platform.

## Note about audio

The demo uses the browser's built-in speech synthesis for pronunciation. You can later replace it with recorded native-speaker MP3 files in a `/public/audio` folder.
